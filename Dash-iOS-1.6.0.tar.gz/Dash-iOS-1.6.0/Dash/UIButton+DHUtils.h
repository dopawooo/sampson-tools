#import <UIKit/UIKit.h>

@interface UIButton (DHUtils)

@property(nonatomic, assign) UIEdgeInsets hitTestEdgeInsets;

@end
