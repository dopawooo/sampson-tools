window.onhashchange = function () {
    window.dash.webViewDidChangeLocationWithinPage();
}
